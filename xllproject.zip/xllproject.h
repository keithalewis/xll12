// $projectname$.h
#include "xll12/xll/xll.h"

// Function Wizard category
#ifndef CATEGORY
#define CATEGORY L"XLL"
#endif
